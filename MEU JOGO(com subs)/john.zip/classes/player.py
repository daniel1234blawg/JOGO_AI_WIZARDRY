import pygame
import math
from settings import BLUE, keybinds, current_width, current_height
from assets import PLAYER_SPRITES
from utils import scale_image_aspect
from classes.spells import Fireball

class Player:
    def __init__(self, x, y):
        self.scale = 1.8  # 2x bigger
        self.rect = pygame.Rect(x, y, 40 * self.scale, 60 * self.scale)
        self.color = BLUE
        self.speed = 5
        self.facing = "up"
        self.spells = [Fireball()]
        self.health = 100
        self.max_health = 100

    def update(self, keys):
        dx, dy = 0, 0
        if any(keys[k] for k in keybinds["move_up"]): dy -= 1
        if any(keys[k] for k in keybinds["move_down"]): dy += 1
        if any(keys[k] for k in keybinds["move_left"]): dx -= 1
        if any(keys[k] for k in keybinds["move_right"]): dx += 1

        if dx != 0 or dy != 0:
            length = math.hypot(dx, dy)
            dx /= length
            dy /= length
            if dx > 0:
                self.facing = "right"
            elif dx < 0:
                self.facing = "left"
            elif dy > 0:
                self.facing = "down"
            elif dy < 0:
                self.facing = "up"

        new_x = self.rect.x + dx * self.speed
        new_y = self.rect.y + dy * self.speed
        self.rect.x = max(0, min(int(new_x), current_width - self.rect.width))
        self.rect.y = max(0, min(int(new_y), current_height - self.rect.height))

    def draw(self, surface):
        sprite = PLAYER_SPRITES[self.facing]
        sprite_scaled = scale_image_aspect(sprite, (self.rect.width, self.rect.height))
        surface.blit(sprite_scaled, self.rect.topleft)
