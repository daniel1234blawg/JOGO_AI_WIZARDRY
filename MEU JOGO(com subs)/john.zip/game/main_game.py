import pygame
import sys
from classes.player import Player
from settings import current_width, current_height, BG_COLOR, FPS, keybinds, DARK_GRAY, WHITE, MAGIC_GOLD
from ui.hud import draw_hud
from ui.hud import draw_fireball_cooldown



def main_game(screen, FONT, SMALL_FONT, TINY_FONT, TITLE_FONT, clock):
    player = Player(current_width // 2 - 32, current_height // 2 - 32)
    projectiles = []
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                for spell in player.spells:
                    if event.key in keybinds["fireball"]:
                        mouse_pos = pygame.mouse.get_pos()
                        if spell.cast(player, projectiles, mouse_pos):
                            continue
                if event.key == pygame.K_ESCAPE:
                    return #to be added (dont touch)
        keys = pygame.key.get_pressed()
        player.update(keys)
        projectiles = [proj for proj in projectiles if proj.update()]
        screen.fill(BG_COLOR)
        player.draw(screen)
        for proj in projectiles:
            proj.draw(screen)
        draw_fireball_cooldown(
            screen,
            player.spells[0],
            keybinds,
            40, 40, 300, 36,  # Posição e tamanho
            SMALL_FONT,
            MAGIC_GOLD
        )

        draw_hud(screen, player, SMALL_FONT)
        pygame.display.flip()
        clock.tick(FPS)
